﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Entidades
{
    public delegate void FinDeSalida(int bomberoIndex);
    public class Bombero : IArchivos<Bombero>, IArchivos<string>
    {
        private string nombre;
        private List<Salidas> salidas;
        public event FinDeSalida MarcarFin;

        public Bombero(string nombre)
        {
            this.nombre = nombre;
            this.salidas = new List<Salidas>();
        }

        public void AtenderSalida(object bomberoIndex)
        {
            this.salidas.Add(new Salidas());
            Thread.Sleep(2000);
            this.salidas[this.salidas.Count - 1].FinalizarSalida();

            this.MarcarFin((int)bomberoIndex);
        }

        public void Guardar(Bombero info)
        {
            throw new NotImplementedException();
        }

        public Bombero Leer()
        {
            throw new NotImplementedException();
        }

        void IArchivos<string>.Guardar(string info)
        {
            throw new NotImplementedException();
        }

        string IArchivos<string>.Leer()
        {
            throw new NotImplementedException();
        }
    }
}
