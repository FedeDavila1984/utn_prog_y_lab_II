﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enfermedades
{
    public abstract class Microrganismo
    {
        public enum ETipo { Virus, Bacteria };
        public enum EContagiosidad { Baja, Moderada, Alta };

        private string nombre;
        private ETipo tipo;
        private EContagiosidad contagiosidad;

        protected long contador;

        public abstract long IndiceDeContagios { get; }

        public Microrganismo(string nombre) : this (nombre, ETipo.Virus, EContagiosidad.Alta) { }

        public Microrganismo(string nombre, ETipo tipo, EContagiosidad contagiosidad)
        {
            this.nombre = nombre;
            this.tipo = tipo;
            this.contagiosidad = contagiosidad;

            this.contador = 1;
        }

        public virtual string Informe()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(string.Format("El {0} lleva el nombre de {1} y tiene una contagiosidad {2}",
                this.tipo.ToString(), this.nombre, this.contagiosidad));
            sb.Append("Su impacto de contagios se calcula en " + this.IndiceDeContagios);
            return sb.ToString();
        }
    }
}
