﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Threading;
using Entidades;
using Enfermedades;

namespace Ejecutable
{
    class Program
    {
        static void Main(string[] args)
        {
            char entrada;
            do
            {
                Console.WriteLine("MENU:");
                Console.WriteLine("-----");
                Console.WriteLine("1- Configurar");
                Console.WriteLine("2- Simular");
                Console.WriteLine("0- Salir");
                entrada = Console.ReadKey().KeyChar;
                switch (entrada)
                {
                    case '1':
                        Console.Write("Población del Grupo de Prueba: ");
                        string aux = Console.ReadLine();
                        long salida;
                        long.TryParse(aux, out salida);
                        if (salida > 0)
                        {
                            GrupoDePrueba<Gripe>.Poblacion = salida;
                            GrupoDePrueba<Covid19>.Poblacion = salida;
                            GrupoDePrueba<Microrganismo>.Poblacion = salida;
                        }

                        break;
                    case '2':
                        Console.WriteLine("ENFERMEDAD:");
                        Console.WriteLine("-----");
                        Console.WriteLine("1- COVID-19");
                        Console.WriteLine("2- GRIPE");
                        Console.WriteLine("0- Salir");
                        entrada = Console.ReadKey().KeyChar;
                        Console.Clear();

                        Thread t = null;
                        Microrganismo enfermedad = null;
                        switch (entrada)
                        {
                            case '1':
                                GrupoDePrueba<Gripe>.InformeDeAvance += Program.Informe;
                                enfermedad = new Gripe("Cepa Americana", Microrganismo.ETipo.Virus, Microrganismo.EContagiosidad.Moderada);
                                t = new Thread(new ParameterizedThreadStart(GrupoDePrueba<Covid19>.InfectarPoblacion));
                                break;
                            case '2':
                                GrupoDePrueba<Covid19>.InformeDeAvance += Program.Informe;
                                enfermedad = new Covid19("Cepa Británica");
                                t = new Thread(new ParameterizedThreadStart(GrupoDePrueba<Covid19>.InfectarPoblacion));
                                break;
                        }
                        if (t != null && enfermedad != null)
                        {
                            t.Start(enfermedad);
                            t.Join();
                            Console.WriteLine("Toda la población fue infectada! Presione una tecla para continuar.");
                            Console.ReadKey();
                        }
                        break;
                }
                Console.Clear();
            } while (entrada != '0');
        }

        private static void Informe(int dia, long infectados)
        {
            Console.WriteLine("Día {0}: {1} infectados de la población total.", dia, infectados);
        }
    }
}
