﻿
namespace Simulador
{
    partial class SimuladorForm
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SimuladorForm));
            this.txtPoblacion = new System.Windows.Forms.TextBox();
            this.lblPoblacion = new System.Windows.Forms.Label();
            this.lblMicroorganismo = new System.Windows.Forms.Label();
            this.cmbMicroorganismo = new System.Windows.Forms.ComboBox();
            this.txtEvolucion = new System.Windows.Forms.RichTextBox();
            this.btnEjecutar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtPoblacion
            // 
            this.txtPoblacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPoblacion.Location = new System.Drawing.Point(169, 12);
            this.txtPoblacion.Name = "txtPoblacion";
            this.txtPoblacion.Size = new System.Drawing.Size(207, 24);
            this.txtPoblacion.TabIndex = 0;
            // 
            // lblPoblacion
            // 
            this.lblPoblacion.AutoSize = true;
            this.lblPoblacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPoblacion.Location = new System.Drawing.Point(14, 15);
            this.lblPoblacion.Name = "lblPoblacion";
            this.lblPoblacion.Size = new System.Drawing.Size(137, 18);
            this.lblPoblacion.TabIndex = 1;
            this.lblPoblacion.Text = "Población a evaluar";
            // 
            // lblMicroorganismo
            // 
            this.lblMicroorganismo.AutoSize = true;
            this.lblMicroorganismo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMicroorganismo.Location = new System.Drawing.Point(14, 45);
            this.lblMicroorganismo.Name = "lblMicroorganismo";
            this.lblMicroorganismo.Size = new System.Drawing.Size(117, 18);
            this.lblMicroorganismo.TabIndex = 3;
            this.lblMicroorganismo.Text = "Microorganismo";
            // 
            // cmbMicroorganismo
            // 
            this.cmbMicroorganismo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMicroorganismo.FormattingEnabled = true;
            this.cmbMicroorganismo.Items.AddRange(new object[] {
            "Covid-19",
            "Gripe"});
            this.cmbMicroorganismo.Location = new System.Drawing.Point(169, 46);
            this.cmbMicroorganismo.Name = "cmbMicroorganismo";
            this.cmbMicroorganismo.Size = new System.Drawing.Size(207, 21);
            this.cmbMicroorganismo.TabIndex = 4;
            // 
            // txtEvolucion
            // 
            this.txtEvolucion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEvolucion.Location = new System.Drawing.Point(0, 171);
            this.txtEvolucion.Name = "txtEvolucion";
            this.txtEvolucion.Size = new System.Drawing.Size(800, 279);
            this.txtEvolucion.TabIndex = 5;
            this.txtEvolucion.Text = "";
            // 
            // btnEjecutar
            // 
            this.btnEjecutar.Location = new System.Drawing.Point(668, 125);
            this.btnEjecutar.Name = "btnEjecutar";
            this.btnEjecutar.Size = new System.Drawing.Size(120, 40);
            this.btnEjecutar.TabIndex = 6;
            this.btnEjecutar.Text = "&Ejecutar";
            this.btnEjecutar.UseVisualStyleBackColor = true;
            this.btnEjecutar.Click += new System.EventHandler(this.btnEjecutar_Click);
            // 
            // SimuladorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnEjecutar);
            this.Controls.Add(this.txtEvolucion);
            this.Controls.Add(this.cmbMicroorganismo);
            this.Controls.Add(this.lblMicroorganismo);
            this.Controls.Add(this.lblPoblacion);
            this.Controls.Add(this.txtPoblacion);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SimuladorForm";
            this.Text = "Simulador de Pandemia";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SimuladorForm_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPoblacion;
        private System.Windows.Forms.Label lblPoblacion;
        private System.Windows.Forms.Label lblMicroorganismo;
        private System.Windows.Forms.ComboBox cmbMicroorganismo;
        private System.Windows.Forms.RichTextBox txtEvolucion;
        private System.Windows.Forms.Button btnEjecutar;
    }
}

