﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Enfermedades;

namespace Entidades
{
    public delegate void AvanceInfectados(int dia, long infectados);
    public delegate void FinInfectacion();
    // Agregado en clase
    public delegate void ExceptionInfectacion(Exception ex);

    public static class GrupoDePrueba<T> where T : Microrganismo
    {
        private static long poblacion;
        public static event AvanceInfectados InformeDeAvance;
        public static event FinInfectacion FinalizaSimulacion;
        private static T enfermedad;
        // Agregado en clase
        public static event ExceptionInfectacion ErrorEnSimulacion;

        static GrupoDePrueba()
        {
            GrupoDePrueba<T>.poblacion = 10000000;
        }

        public static long Poblacion
        {
            get
            {
                return GrupoDePrueba<T>.poblacion;
            }
            set
            {
                GrupoDePrueba<T>.poblacion = value;
            }
        }

        public static void InfectarPoblacion(object obj)
        {
            // Agregado en clase
            GrupoDePrueba<T>.ErrorEnSimulacion.Invoke(new Exception("ERROR"));

            if (obj is T)
            {
                GrupoDePrueba<T>.enfermedad = (T)obj;
                long infectados = 0;
                int dia = 1;
                do
                {
                    infectados += GrupoDePrueba<T>.enfermedad.IndiceDeContagios;

                    if (infectados > GrupoDePrueba<T>.poblacion)
                        infectados = GrupoDePrueba<T>.poblacion;

                    if (GrupoDePrueba<T>.InformeDeAvance != null)
                        GrupoDePrueba<T>.InformeDeAvance.Invoke(dia, infectados);

                    dia++;
                    System.Threading.Thread.Sleep(750);
                } while (infectados < GrupoDePrueba<T>.poblacion);

                if (GrupoDePrueba<T>.FinalizaSimulacion != null)
                    GrupoDePrueba<T>.FinalizaSimulacion.Invoke();
            }
        }
    }
}
