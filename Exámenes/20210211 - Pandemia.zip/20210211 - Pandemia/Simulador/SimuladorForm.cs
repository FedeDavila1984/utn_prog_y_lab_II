﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Threading;
using Enfermedades;
using Entidades;

namespace Simulador
{
    public partial class SimuladorForm : Form
    {
        Thread hilo;
        public SimuladorForm()
        {
            InitializeComponent();

            this.hilo = null;
        }

        private void btnEjecutar_Click(object sender, EventArgs e)
        {
            long poblacion;
            long.TryParse(this.txtPoblacion.Text, out poblacion);

            if (this.cmbMicroorganismo.Text == "Gripe")
            {
                if (poblacion > 0)
                    GrupoDePrueba<Gripe>.Poblacion = poblacion;
                Gripe enfermedad = new Gripe("Cepa Americana", Microrganismo.ETipo.Virus, Microrganismo.EContagiosidad.Moderada);
                this.txtEvolucion.Text = enfermedad.Informe();
                this.Ejecutar<Gripe>(enfermedad);
            } else
            {
                if (poblacion > 0)
                    GrupoDePrueba<Covid19>.Poblacion = poblacion;
                Covid19 enfermedad = new Covid19("Cepa Británica");
                this.txtEvolucion.Text = enfermedad.Informe();
                this.Ejecutar<Covid19>(enfermedad);
            }
        }

        private void Ejecutar<T>(T enfermedad) where T : Microrganismo
        {
            GrupoDePrueba<T>.InformeDeAvance += this.Informe;
            GrupoDePrueba<T>.FinalizaSimulacion += this.Final;
            GrupoDePrueba<T>.ErrorEnSimulacion += this.FinalPorError;

            ParameterizedThreadStart pts = new ParameterizedThreadStart(GrupoDePrueba<T>.InfectarPoblacion);
            hilo = new Thread(pts);
            // new Thread(GrupoDePrueba<T>.InfectarPoblacion)

            hilo.Start(enfermedad);
        }

        // Agregado en clase
        private void FinalPorError(Exception ex)
        {
            MessageBox.Show(ex.Message);
        }

        private void Informe(int dia, long infectados)
        {
            if (this.txtEvolucion.InvokeRequired)
            {
                AvanceInfectados delegado = new AvanceInfectados(this.Informe);
                this.txtEvolucion.Invoke(delegado, new object[] { dia, infectados });
            } else {
                this.txtEvolucion.Text = string.Format("Día {0}: {1} infectados de la población total.", dia, infectados) + '\n' + this.txtEvolucion.Text;
            }
        }

        private void Final()
        {
            if (this.txtEvolucion.InvokeRequired)
            {
                FinInfectacion delegado = new FinInfectacion(this.Final);
                this.txtEvolucion.Invoke(delegado);
            }
            else
            {
                this.txtEvolucion.Text = "¡Toda la población fue infectada!" + '\n' + this.txtEvolucion.Text;
            }
        }

        private void SimuladorForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.hilo != null)
            {
                this.hilo.Abort();
            }
        }
    }
}
